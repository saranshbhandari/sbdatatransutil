package com.example.datatransfer.writer;

import com.example.datatransfer.model.DataTaskSettings;
import com.example.datatransfer.util.DataConverter;
import com.example.datatransfer.util.FileUtil;
import java.io.*;
import java.util.*;

public class CsvFileWriter implements DataWriter {
    private BufferedWriter writer;
    private File tempFile;
    private File finalFile;
    private boolean headerWritten = false;
    private DataTaskSettings settings;

    @Override
    public void open(DataTaskSettings settings) throws Exception {
        this.settings = settings;
        String baseName = settings.getDestFileNamePattern() != null
                ? settings.getDestFileNamePattern()
                : "data-{datetime}.csv";
        String timestamp = FileUtil.getCurrentTimestamp();
        String fileName = baseName.replace("{datetime}", timestamp);
        finalFile = new File(settings.getDestFileDirectory(), fileName);
        if (settings.isRollbackOnError()) {
            tempFile = File.createTempFile("tmp-", ".csv", new File(settings.getDestFileDirectory()));
        } else {
            tempFile = finalFile;
        }
        writer = new BufferedWriter(new FileWriter(tempFile));
    }

    @Override
    public void writeBatch(List<Map<String, Object>> batch) throws Exception {
        if (batch.isEmpty()) return;
        if (!headerWritten) {
            Collection<String> cols = settings.getFieldMappings() != null
                    ? settings.getFieldMappings().values()
                    : batch.get(0).keySet();
            writer.write(String.join(String.valueOf(settings.getCsvDelimiter()), cols));
            writer.newLine();
            headerWritten = true;
        }
        for (Map<String, Object> rec : batch) {
            Map<String, Object> destRec = applyMappingAndConversion(rec);
            StringJoiner joiner = new StringJoiner(String.valueOf(settings.getCsvDelimiter()));
            destRec.values().forEach(val -> joiner.add(val != null ? val.toString() : ""));
            writer.write(joiner.toString());
            writer.newLine();
        }
        writer.flush();
    }

    @Override
    public void commit() throws Exception {
        writer.close();
        if (settings.isRollbackOnError() && !tempFile.equals(finalFile)) {
            if (!tempFile.renameTo(finalFile)) {
                throw new IOException("Failed to rename temp file to final name");
            }
        }
    }

    @Override
    public void rollback() throws Exception {
        writer.close();
        if (settings.isRollbackOnError() && tempFile.exists() && !tempFile.equals(finalFile)) {
            tempFile.delete();
        }
    }

    @Override
    public void close() throws Exception {
        if (writer != null) writer.close();
    }

    private Map<String, Object> applyMappingAndConversion(Map<String, Object> source) {
        Map<String, Object> dest = new LinkedHashMap<>();
        if (settings.getFieldMappings() != null) {
            settings.getFieldMappings().forEach((src, dst) -> {
                Object val = source.get(src);
                Class<?> type = settings.getDestFieldTypes() != null
                        ? settings.getDestFieldTypes().get(dst) : null;
                if (type != null) val = DataConverter.convertValue(val, type);
                dest.put(dst, val);
            });
        } else {
            source.forEach((k, v) -> {
                Class<?> type = settings.getDestFieldTypes() != null
                        ? settings.getDestFieldTypes().get(k) : null;
                if (type != null) v = DataConverter.convertValue(v, type);
                dest.put(k, v);
            });
        }
        return dest;
    }
}
