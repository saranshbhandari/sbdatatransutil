package com.example.datatransfer.writer;

import com.example.datatransfer.config.ConnectionPoolFactory;
import com.example.datatransfer.model.DataTaskSettings;
import com.example.datatransfer.util.DataConverter;
import javax.sql.DataSource;
import java.sql.*;
import java.util.*;
import java.util.stream.Collectors;

public class DatabaseWriter implements DataWriter {
    private Connection connection;
    private PreparedStatement insertStmt;
    private boolean autoCommitDefault;
    private DataTaskSettings settings;

    @Override
    public void open(DataTaskSettings settings) throws Exception {
        this.settings = settings;
        DataSource ds = ConnectionPoolFactory.getConnectionPool(settings.getDestDatabaseId());
        connection = ds.getConnection();
        autoCommitDefault = connection.getAutoCommit();
        if (settings.isRollbackOnError()) {
            connection.setAutoCommit(false);
        }
    }

    @Override
    public void writeBatch(List<Map<String, Object>> batch) throws Exception {
        if (batch.isEmpty()) return;
        if (insertStmt == null) {
            List<String> cols = settings.getFieldMappings() != null
                    ? new ArrayList<>(settings.getFieldMappings().values())
                    : new ArrayList<>(batch.get(0).keySet());
            String colList = String.join(", ", cols);
            String placeholders = cols.stream().map(c -> "?").collect(Collectors.joining(", "));
            String sql = "INSERT INTO " + settings.getDestTableName() +
                    " (" + colList + ") VALUES (" + placeholders + ")";
            insertStmt = connection.prepareStatement(sql);
        }
        for (Map<String, Object> rec : batch) {
            Map<String, Object> destRec = applyMappingAndConversion(rec);
            int idx = 1;
            for (Object val : destRec.values()) {
                insertStmt.setObject(idx++, val);
            }
            insertStmt.addBatch();
        }
        insertStmt.executeBatch();
        if (!settings.isRollbackOnError()) {
            connection.commit();
        }
    }

    @Override
    public void commit() throws Exception {
        if (settings.isRollbackOnError()) {
            connection.commit();
        }
    }

    @Override
    public void rollback() throws Exception {
        if (settings.isRollbackOnError()) {
            connection.rollback();
        }
    }

    @Override
    public void close() throws Exception {
        if (insertStmt != null) insertStmt.close();
        if (connection != null) {
            connection.setAutoCommit(autoCommitDefault);
            connection.close();
        }
    }

    private Map<String, Object> applyMappingAndConversion(Map<String, Object> source) {
        Map<String, Object> dest = new LinkedHashMap<>();
        if (settings.getFieldMappings() != null) {
            settings.getFieldMappings().forEach((src, dst) -> {
                Object val = source.get(src);
                Class<?> targetType = settings.getDestFieldTypes() != null
                        ? settings.getDestFieldTypes().get(dst) : null;
                if (targetType != null) {
                    val = DataConverter.convertValue(val, targetType);
                }
                dest.put(dst, val);
            });
        } else {
            source.forEach((k, v) -> {
                Class<?> targetType = settings.getDestFieldTypes() != null
                        ? settings.getDestFieldTypes().get(k) : null;
                if (targetType != null) {
                    v = DataConverter.convertValue(v, targetType);
                }
                dest.put(k, v);
            });
        }
        return dest;
    }
}
