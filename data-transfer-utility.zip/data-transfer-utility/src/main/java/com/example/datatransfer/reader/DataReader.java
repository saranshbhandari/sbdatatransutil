package com.example.datatransfer.reader;

import com.example.datatransfer.model.DataTaskSettings;
import java.util.List;
import java.util.Map;

public interface DataReader extends AutoCloseable {
    void open(DataTaskSettings settings) throws Exception;
    List<Map<String, Object>> readBatch() throws Exception;
    @Override
    void close() throws Exception;
}
