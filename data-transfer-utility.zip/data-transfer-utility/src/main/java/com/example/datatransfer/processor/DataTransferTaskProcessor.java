package com.example.datatransfer.processor;

import com.example.datatransfer.enums.SourceType;
import com.example.datatransfer.enums.DestinationType;
import com.example.datatransfer.model.DataTaskSettings;
import com.example.datatransfer.model.RecordTransformer;
import com.example.datatransfer.reader.*;
import com.example.datatransfer.writer.*;
import java.util.*;
import java.util.concurrent.*;

public class DataTransferTaskProcessor {

    public void processTask(DataTaskSettings settings) throws Exception {
        DataReader reader;
        DataWriter writer;
        switch (settings.getSourceType()) {
            case DATABASE: reader = new DatabaseReader(); break;
            case FILE_CSV: reader = new CsvFileReader(); break;
            case FILE_EXCEL: reader = new ExcelFileReader(); break;
            case SCRIPT: reader = new ScriptReader(); break;
            default: throw new IllegalArgumentException("Unsupported source type");
        }
        switch (settings.getDestType()) {
            case DATABASE: writer = new DatabaseWriter(); break;
            case FILE_CSV: writer = new CsvFileWriter(); break;
            case FILE_EXCEL: writer = new ExcelFileWriter(); break;
            default: throw new IllegalArgumentException("Unsupported destination type");
        }

        try (DataReader r = reader; DataWriter w = writer) {
            r.open(settings);
            w.open(settings);
            boolean error = false;
            Exception ex = null;
            if (settings.isParallelProcessing()) {
                List<List<Map<String, Object>>> batches = new ArrayList<>();
                List<Map<String, Object>> batch;
                while (!(batch = r.readBatch()).isEmpty()) {
                    batch = transformBatch(batch, settings.getTransformer());
                    if (!batch.isEmpty()) batches.add(batch);
                }
                ExecutorService exec = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
                List<Future<?>> futures = new ArrayList<>();
                for (List<Map<String, Object>> b : batches) {
                    futures.add(exec.submit(() -> {
                        try { w.writeBatch(b); }
                        catch (Exception e) { throw new RuntimeException(e); }
                    }));
                }
                exec.shutdown();
                for (Future<?> f : futures) {
                    try { f.get(); }
                    catch (ExecutionException ee) {
                        error = true;
                        ex = ee;
                        exec.shutdownNow();
                        break;
                    }
                }
            } else {
                List<Map<String, Object>> batch;
                while (!(batch = r.readBatch()).isEmpty()) {
                    batch = transformBatch(batch, settings.getTransformer());
                    if (batch.isEmpty()) continue;
                    try { w.writeBatch(batch); }
                    catch (Exception e) {
                        error = true;
                        ex = e;
                        break;
                    }
                }
            }
            if (error) {
                if (settings.isRollbackOnError()) w.rollback();
                throw ex;
            } else {
                w.commit();
            }
        }
    }

    private List<Map<String, Object>> transformBatch(List<Map<String, Object>> batch, RecordTransformer transformer) {
        if (transformer == null) return batch;
        List<Map<String, Object>> result = new ArrayList<>();
        for (Map<String, Object> rec : batch) {
            Map<String, Object> tr = transformer.transform(rec);
            if (tr != null) result.add(tr);
        }
        return result;
    }
}
