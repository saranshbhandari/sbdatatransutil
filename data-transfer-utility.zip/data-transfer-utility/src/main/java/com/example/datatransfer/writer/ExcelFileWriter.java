package com.example.datatransfer.writer;

import com.example.datatransfer.model.DataTaskSettings;
import com.example.datatransfer.util.DataConverter;
import com.example.datatransfer.util.FileUtil;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.*;
import java.util.*;

public class ExcelFileWriter implements DataWriter {
    private Workbook workbook;
    private Sheet sheet;
    private int currentRow = 0;
    private File tempFile;
    private File finalFile;
    private DataTaskSettings settings;

    @Override
    public void open(DataTaskSettings settings) throws Exception {
        this.settings = settings;
        workbook = new XSSFWorkbook();
        sheet = workbook.createSheet(
                settings.getExcelOutputSheetName() != null
                        ? settings.getExcelOutputSheetName() : "Data");
        String baseName = settings.getDestFileNamePattern() != null
                ? settings.getDestFileNamePattern() : "data-{datetime}.xlsx";
        String timestamp = FileUtil.getCurrentTimestamp();
        String fileName = baseName.replace("{datetime}", timestamp);
        finalFile = new File(settings.getDestFileDirectory(), fileName);
        if (settings.isRollbackOnError()) {
            tempFile = File.createTempFile("tmp-", ".xlsx", new File(settings.getDestFileDirectory()));
        } else {
            tempFile = finalFile;
        }
    }

    @Override
    public void writeBatch(List<Map<String, Object>> batch) throws Exception {
        if (batch.isEmpty()) return;
        if (currentRow == 0) {
            Row headerRow = sheet.createRow(currentRow++);
            List<String> headers = settings.getFieldMappings() != null
                    ? new ArrayList<>(settings.getFieldMappings().values())
                    : new ArrayList<>(batch.get(0).keySet());
            for (int i = 0; i < headers.size(); i++) {
                headerRow.createCell(i).setCellValue(headers.get(i));
            }
        }
        for (Map<String, Object> rec : batch) {
            Map<String, Object> destRec = applyMappingAndConversion(rec);
            Row row = sheet.createRow(currentRow++);
            int colIdx = 0;
            for (Object val : destRec.values()) {
                Cell cell = row.createCell(colIdx++);
                if (val == null) {
                    cell.setBlank();
                } else if (val instanceof Number) {
                    cell.setCellValue(((Number) val).doubleValue());
                } else if (val instanceof Boolean) {
                    cell.setCellValue((Boolean) val);
                } else if (val instanceof Date) {
                    cell.setCellValue((Date) val);
                } else {
                    cell.setCellValue(val.toString());
                }
            }
        }
    }

    @Override
    public void commit() throws Exception {
        try (FileOutputStream fos = new FileOutputStream(tempFile)) {
            workbook.write(fos);
        }
        workbook.close();
        if (settings.isRollbackOnError() && !tempFile.equals(finalFile)) {
            if (!tempFile.renameTo(finalFile)) {
                throw new IOException("Failed to rename temp file");
            }
        }
    }

    @Override
    public void rollback() throws Exception {
        workbook.close();
        if (settings.isRollbackOnError() && tempFile.exists() && !tempFile.equals(finalFile)) {
            tempFile.delete();
        }
    }

    @Override
    public void close() throws Exception {
        if (workbook != null) workbook.close();
    }

    private Map<String, Object> applyMappingAndConversion(Map<String, Object> source) {
        Map<String, Object> dest = new LinkedHashMap<>();
        if (settings.getFieldMappings() != null) {
            settings.getFieldMappings().forEach((src, dst) -> {
                Object val = source.get(src);
                Class<?> type = settings.getDestFieldTypes() != null
                        ? settings.getDestFieldTypes().get(dst) : null;
                if (type != null) val = DataConverter.convertValue(val, type);
                dest.put(dst, val);
            });
        } else {
            source.forEach((k, v) -> {
                Class<?> type = settings.getDestFieldTypes() != null
                        ? settings.getDestFieldTypes().get(k) : null;
                if (type != null) v = DataConverter.convertValue(v, type);
                dest.put(k, v);
            });
        }
        return dest;
    }
}
