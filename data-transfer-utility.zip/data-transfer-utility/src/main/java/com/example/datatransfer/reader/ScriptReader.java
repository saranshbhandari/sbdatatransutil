package com.example.datatransfer.reader;

import com.example.datatransfer.model.DataTaskSettings;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.*;

public class ScriptReader implements DataReader {
    private DataTaskSettings settings;
    private BufferedReader scriptOutput;
    private Process process;

    @Override
    public void open(DataTaskSettings settings) throws Exception {
        this.settings = settings;
        process = new ProcessBuilder(settings.getSourceScript().split(" ")).start();
        scriptOutput = new BufferedReader(new InputStreamReader(process.getInputStream()));
    }

    @Override
    public List<Map<String, Object>> readBatch() throws Exception {
        List<Map<String, Object>> batch = new ArrayList<>();
        String line;
        int count = 0;
        char delim = settings.getCsvDelimiter() != null ? settings.getCsvDelimiter() : ',';
        while (count < settings.getBatchSize() && (line = scriptOutput.readLine()) != null) {
            String[] tokens = line.split(String.valueOf(delim));
            Map<String, Object> record = new HashMap<>();
            for (int i = 0; i < tokens.length; i++) {
                record.put("COL" + (i + 1), tokens[i]);
            }
            batch.add(record);
            count++;
        }
        return batch;
    }

    @Override
    public void close() throws Exception {
        if (scriptOutput != null) scriptOutput.close();
        if (process != null) process.destroyForcibly();
    }
}
