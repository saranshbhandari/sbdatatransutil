package com.example.datatransfer.util;

import java.sql.Timestamp;
import java.util.Date;

public class DataConverter {
    public static Object convertValue(Object value, Class<?> targetType) {
        if (value == null) return null;
        if (targetType.isAssignableFrom(value.getClass())) {
            return value;
        }
        String strVal = value.toString();
        try {
            if (targetType == Integer.class || targetType == int.class) {
                return Integer.parseInt(strVal);
            } else if (targetType == Long.class || targetType == long.class) {
                return Long.parseLong(strVal);
            } else if (targetType == Double.class || targetType == double.class) {
                return Double.parseDouble(strVal);
            } else if (targetType == Boolean.class || targetType == boolean.class) {
                if (strVal.equalsIgnoreCase("true") || strVal.equals("1")) {
                    return true;
                } else if (strVal.equalsIgnoreCase("false") || strVal.equals("0")) {
                    return false;
                } else {
                    return Boolean.parseBoolean(strVal);
                }
            } else if (targetType == Date.class) {
                return Timestamp.valueOf(strVal);
            } else if (targetType == String.class) {
                return strVal;
            }
        } catch (Exception e) {
            throw new RuntimeException("Failed to convert value: '" + value + "' to type " + targetType, e);
        }
        return value;
    }
}
