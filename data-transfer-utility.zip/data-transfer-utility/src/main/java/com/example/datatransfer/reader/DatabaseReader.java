package com.example.datatransfer.reader;

import com.example.datatransfer.config.ConnectionPoolFactory;
import com.example.datatransfer.model.DataTaskSettings;
import javax.sql.DataSource;
import java.sql.*;
import java.util.*;

public class DatabaseReader implements DataReader {
    private Connection connection;
    private PreparedStatement statement;
    private ResultSet resultSet;
    private int batchSize;

    @Override
    public void open(DataTaskSettings settings) throws Exception {
        DataSource ds = ConnectionPoolFactory.getConnectionPool(settings.getSourceDatabaseId());
        connection = ds.getConnection();
        connection.setAutoCommit(false);
        batchSize = settings.getBatchSize();
        statement = connection.prepareStatement(settings.getSourceQuery(),
                ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
        statement.setFetchSize(batchSize);
        resultSet = statement.executeQuery();
    }

    @Override
    public List<Map<String, Object>> readBatch() throws Exception {
        List<Map<String, Object>> batch = new ArrayList<>();
        int count = 0;
        while (count < batchSize && resultSet.next()) {
            ResultSetMetaData meta = resultSet.getMetaData();
            int colCount = meta.getColumnCount();
            Map<String, Object> record = new HashMap<>();
            for (int i = 1; i <= colCount; i++) {
                record.put(meta.getColumnLabel(i), resultSet.getObject(i));
            }
            batch.add(record);
            count++;
        }
        return batch;
    }

    @Override
    public void close() throws Exception {
        if (resultSet != null) resultSet.close();
        if (statement != null) statement.close();
        if (connection != null) connection.close();
    }
}
