package com.example.datatransfer.reader;

import com.example.datatransfer.model.DataTaskSettings;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.DateUtil;
import java.io.File;
import java.util.*;

public class ExcelFileReader implements DataReader {
    private DataTaskSettings settings;
    private Workbook workbook;
    private Sheet sheet;
    private int nextRowIndex, lastRowIndex;

    @Override
    public void open(DataTaskSettings settings) throws Exception {
        this.settings = settings;
        workbook = WorkbookFactory.create(new File(settings.getSourceFilePath()));
        sheet = (settings.getExcelSheetName() != null)
                ? workbook.getSheet(settings.getExcelSheetName())
                : workbook.getSheetAt(0);
        boolean hasHeader = settings.isCsvHasHeader();
        nextRowIndex = hasHeader ? 1 : 0;
        lastRowIndex = sheet.getLastRowNum();
    }

    @Override
    public List<Map<String, Object>> readBatch() throws Exception {
        List<Map<String, Object>> batch = new ArrayList<>();
        int count = 0;
        // Get column names if header row exists
        String[] columnNames = null;
        if (settings.isCsvHasHeader() && sheet.getRow(0) != null) {
            Row headerRow = sheet.getRow(0);
            int cellCount = headerRow.getLastCellNum();
            columnNames = new String[cellCount];
            for (int c = 0; c < cellCount; c++) {
                Cell cell = headerRow.getCell(c);
                columnNames[c] = (cell != null ? cell.toString() : "COL" + (c + 1));
            }
        }
        while (count < settings.getBatchSize() && nextRowIndex <= lastRowIndex) {
            Row row = sheet.getRow(nextRowIndex++);
            if (row == null) continue;
            Map<String, Object> record = new HashMap<>();
            short lastCell = row.getLastCellNum();
            for (int cn = 0; cn < lastCell; cn++) {
                Cell cell = row.getCell(cn);
                Object value;
                if (cell == null) {
                    value = null;
                } else {
                    switch (cell.getCellType()) {
                        case STRING: value = cell.getStringCellValue(); break;
                        case NUMERIC:
                            if (DateUtil.isCellDateFormatted(cell)) {
                                value = cell.getDateCellValue();
                            } else {
                                value = cell.getNumericCellValue();
                            }
                            break;
                        case BOOLEAN: value = cell.getBooleanCellValue(); break;
                        case FORMULA:
                            try { value = cell.getNumericCellValue(); }
                            catch (Exception e) { value = cell.toString(); }
                            break;
                        default: value = cell.toString();
                    }
                }
                String key = (columnNames != null && cn < columnNames.length)
                        ? columnNames[cn] : "COL" + (cn + 1);
                record.put(key, value);
            }
            batch.add(record);
            count++;
        }
        return batch;
    }

    @Override
    public void close() throws Exception {
        if (workbook != null) workbook.close();
    }
}
