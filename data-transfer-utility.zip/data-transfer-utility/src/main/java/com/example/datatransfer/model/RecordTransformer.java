package com.example.datatransfer.model;

import java.util.Map;

@FunctionalInterface
public interface RecordTransformer {
    Map<String, Object> transform(Map<String, Object> record);
}
