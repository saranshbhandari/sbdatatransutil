package com.example.datatransfer.model;

import com.example.datatransfer.enums.SourceType;
import com.example.datatransfer.enums.DestinationType;
import java.util.Map;

public class DataTaskSettings {
    private SourceType sourceType;
    private String sourceDatabaseId;
    private String sourceQuery;
    private String sourceFilePath;
    private String sourceScript;
    private Character csvDelimiter;
    private boolean csvHasHeader;
    private String excelSheetName;

    private DestinationType destType;
    private String destDatabaseId;
    private String destTableName;
    private String destFileDirectory;
    private String destFileNamePattern;
    private String excelOutputSheetName;

    private int batchSize;
    private boolean rollbackOnError;
    private boolean parallelProcessing;

    private Map<String, String> fieldMappings;
    private Map<String, Class<?>> destFieldTypes;

    private RecordTransformer transformer;

    public DataTaskSettings() {
        this.batchSize = 1000;
        this.rollbackOnError = false;
        this.parallelProcessing = false;
        this.csvHasHeader = false;
        this.csvDelimiter = null;
    }

    // Getters and setters omitted for brevity
    // Add getters and setters for all fields or use Lombok @Data
}
