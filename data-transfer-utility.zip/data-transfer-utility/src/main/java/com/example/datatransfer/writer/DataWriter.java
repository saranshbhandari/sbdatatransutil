package com.example.datatransfer.writer;

import com.example.datatransfer.model.DataTaskSettings;
import java.util.List;
import java.util.Map;

public interface DataWriter extends AutoCloseable {
    void open(DataTaskSettings settings) throws Exception;
    void writeBatch(List<Map<String, Object>> batch) throws Exception;
    void commit() throws Exception;
    void rollback() throws Exception;
    @Override
    void close() throws Exception;
}
