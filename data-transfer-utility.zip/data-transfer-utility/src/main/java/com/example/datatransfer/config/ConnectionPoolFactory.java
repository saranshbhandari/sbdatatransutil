package com.example.datatransfer.config;

import javax.sql.DataSource;
import org.springframework.stereotype.Component;
import java.util.HashMap;
import java.util.Map;

@Component
public class ConnectionPoolFactory {
    private static Map<String, DataSource> dataSources = new HashMap<>();

    static {
        // Initialize your DataSources here, e.g.,
        // dataSources.put("oracleDb", createOracleDataSource());
        // dataSources.put("mysqlDb", createMySqlDataSource());
        // dataSources.put("mssqlDb", createMssqlDataSource());
    }

    public static DataSource getConnectionPool(String databaseId) {
        DataSource ds = dataSources.get(databaseId);
        if (ds == null) {
            throw new IllegalArgumentException("No DataSource configured for id: " + databaseId);
        }
        return ds;
    }
}
