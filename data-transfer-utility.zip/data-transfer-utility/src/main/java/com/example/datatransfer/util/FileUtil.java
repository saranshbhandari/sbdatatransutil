package com.example.datatransfer.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class FileUtil {
    public static String getCurrentTimestamp() {
        return DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss").format(LocalDateTime.now());
    }
}
