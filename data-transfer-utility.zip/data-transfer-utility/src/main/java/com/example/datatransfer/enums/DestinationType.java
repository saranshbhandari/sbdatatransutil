package com.example.datatransfer.enums;

public enum DestinationType {
    DATABASE,
    FILE_CSV,
    FILE_EXCEL
}
