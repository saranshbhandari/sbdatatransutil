package com.example.datatransfer.reader;

import com.example.datatransfer.model.DataTaskSettings;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.*;

public class CsvFileReader implements DataReader {
    private BufferedReader reader;
    private DataTaskSettings settings;
    private String[] headers;
    private boolean headerRead = false;

    @Override
    public void open(DataTaskSettings settings) throws Exception {
        this.settings = settings;
        reader = new BufferedReader(new FileReader(settings.getSourceFilePath()));
        if (settings.isCsvHasHeader()) {
            String headerLine = reader.readLine();
            if (headerLine != null) {
                headers = headerLine.split(String.valueOf(settings.getCsvDelimiter()));
            }
            headerRead = true;
        }
    }

    @Override
    public List<Map<String, Object>> readBatch() throws Exception {
        List<Map<String, Object>> batch = new ArrayList<>();
        String line;
        int count = 0;
        while (count < settings.getBatchSize() && (line = reader.readLine()) != null) {
            if (!headerRead && settings.isCsvHasHeader()) {
                headers = line.split(String.valueOf(settings.getCsvDelimiter()));
                headerRead = true;
                continue;
            }
            String[] tokens = line.split(String.valueOf(settings.getCsvDelimiter()));
            Map<String, Object> record = new HashMap<>();
            if (headers != null && headers.length == tokens.length) {
                for (int i = 0; i < tokens.length; i++) {
                    record.put(headers[i], tokens[i]);
                }
            } else {
                for (int i = 0; i < tokens.length; i++) {
                    record.put("COL" + (i + 1), tokens[i]);
                }
            }
            batch.add(record);
            count++;
        }
        return batch;
    }

    @Override
    public void close() throws Exception {
        if (reader != null) reader.close();
    }
}
