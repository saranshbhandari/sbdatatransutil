package com.example.datatransfer.enums;

public enum SourceType {
    DATABASE,
    FILE_CSV,
    FILE_EXCEL,
    SCRIPT
}
