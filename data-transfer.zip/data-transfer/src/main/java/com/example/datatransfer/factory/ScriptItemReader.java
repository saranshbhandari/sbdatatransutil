package com.example.datatransfer.factory;

import com.example.datatransfer.model.ScriptSettings;
import com.example.datatransfer.model.SourceDestinationMapping;
import org.springframework.batch.item.*;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.database.builder.JdbcCursorItemReaderBuilder;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

public class ScriptItemReader implements ItemReader<Map<String,Object>>, ItemStream, InitializingBean {
    private final ScriptSettings scriptSettings;
    private final List<SourceDestinationMapping> mappings;
    private JdbcCursorItemReader<Map<String,Object>> delegate;

    public ScriptItemReader(ScriptSettings scriptSettings, List<SourceDestinationMapping> mappings) {
        this.scriptSettings = scriptSettings;
        this.mappings = mappings;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        DataSource ds = ConnectionPoolFactory.getConnectionPool(scriptSettings.getDatabaseId());
        this.delegate = new JdbcCursorItemReaderBuilder<Map<String,Object>>()
            .name("scriptItemReader-" + System.identityHashCode(this))
            .dataSource(ds)
            .sql(scriptSettings.getScript())
            .rowMapper(new RowMapper<Map<String,Object>>() {
                @Override
                public Map<String,Object> mapRow(ResultSet rs, int rowNum) throws SQLException {
                    Map<String,Object> row = new HashMap<>();
                    for (var m : mappings) {
                        row.put(m.getSourceColumnName(), rs.getObject(m.getSourceColumnName()));
                    }
                    return row;
                }
            })
            .build();
        this.delegate.afterPropertiesSet();
    }

    @Override
    public Map<String,Object> read() throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
        return delegate.read();
    }

    @Override
    public void open(ExecutionContext executionContext) throws ItemStreamException {
        delegate.open(executionContext);
    }

    @Override
    public void update(ExecutionContext executionContext) throws ItemStreamException {
        delegate.update(executionContext);
    }

    @Override
    public void close() throws ItemStreamException {
        delegate.close();
    }
}
