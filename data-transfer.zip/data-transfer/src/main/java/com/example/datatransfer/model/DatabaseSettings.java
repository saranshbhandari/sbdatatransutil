package com.example.datatransfer.model;

public class DatabaseSettings {
    private Long databaseId;
    private String databaseName;
    private String databaseType;
    private String schemaName;
    private String tableName;
    // getters & setters
}
