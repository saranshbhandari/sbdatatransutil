package com.example.datatransfer.factory;

import org.springframework.batch.item.ItemReader;
import org.springframework.beans.factory.InitializingBean;

public class ExcelItemReader implements ItemReader<Map<String,Object>>, InitializingBean {
    public ExcelItemReader(String path, List<SourceDestinationMapping> mappings, boolean header) {
        // stub: use Apache POI to implement
    }
    @Override public void afterPropertiesSet() {}
    @Override public Map<String,Object> read() { throw new UnsupportedOperationException("Excel reader not implemented"); }
}
