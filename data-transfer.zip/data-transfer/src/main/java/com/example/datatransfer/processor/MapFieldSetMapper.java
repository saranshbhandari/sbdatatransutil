package com.example.datatransfer.processor;

import com.example.datatransfer.model.SourceDestinationMapping;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import java.util.*;

public class MapFieldSetMapper implements FieldSetMapper<Map<String,Object>> {
    private final List<SourceDestinationMapping> mappings;
    private final boolean header;
    public MapFieldSetMapper(List<SourceDestinationMapping> mappings, boolean header) {
        this.mappings = mappings;
        this.header = header;
    }
    @Override
    public Map<String,Object> mapFieldSet(FieldSet fs) {
        var map = new HashMap<String,Object>();
        for (int i = 0; i < mappings.size(); i++) {
            String key = header ? mappings.get(i).getSourceColumnName() : "col" + i;
            map.put(mappings.get(i).getSourceColumnName(), fs.readRaw(key));
        }
        return map;
    }
}
