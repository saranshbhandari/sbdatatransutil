package com.example.datatransfer.factory;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.InitializingBean;

public class ExcelItemWriter implements ItemWriter<Map<String,Object>>, InitializingBean {
    public ExcelItemWriter(String path, List<SourceDestinationMapping> mappings) {
        // stub: use Apache POI to implement
    }
    @Override public void afterPropertiesSet(){}
    @Override public void write(List<? extends Map<String,Object>> items) { throw new UnsupportedOperationException("Excel writer not implemented"); }
}
