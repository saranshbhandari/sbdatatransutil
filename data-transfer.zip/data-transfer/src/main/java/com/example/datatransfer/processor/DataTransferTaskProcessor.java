package com.example.datatransfer.processor;

import com.example.datatransfer.factory.ReaderFactory;
import com.example.datatransfer.factory.WriterFactory;
import com.example.datatransfer.model.DataTaskSettings;
import org.springframework.batch.core.*;
import org.springframework.batch.core.configuration.JobRegistry;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.step.builder.StepBuilderFactory;
import org.springframework.batch.core.job.builder.JobBuilderFactory;
import org.springframework.stereotype.Service;

@Service
public class DataTransferTaskProcessor {
    private final JobLauncher jobLauncher;
    private final StepBuilderFactory stepBuilderFactory;
    private final JobBuilderFactory jobBuilderFactory;
    private final JobRegistry jobRegistry;

    public DataTransferTaskProcessor(JobLauncher jl, StepBuilderFactory sbf, JobBuilderFactory jbf, JobRegistry jr) {
        this.jobLauncher = jl;
        this.stepBuilderFactory = sbf;
        this.jobBuilderFactory = jbf;
        this.jobRegistry = jr;
    }

    public void processTask(DataTaskSettings settings) throws Exception {
        String jobName = "dataTransferJob-" + System.currentTimeMillis();
        Step step = stepBuilderFactory.get("step-"+System.currentTimeMillis())
            .<Map<String,Object>,Map<String,Object>>chunk(settings.getBatchSize())
            .reader(ReaderFactory.get(settings.getSource(), settings.getMappings()))
            .processor(new TransformationProcessor(settings.getMappings()))
            .writer(WriterFactory.get(settings.getDestination(), settings.getMappings()))
            .build();

        Job job = jobBuilderFactory.get(jobName)
            .start(step)
            .build();

        jobRegistry.register(new ReferenceJobFactory(job));
        JobExecution exec = jobLauncher.run(job, new JobParametersBuilder()
            .addLong("ts", System.currentTimeMillis()).toJobParameters());

        if (exec.getStatus() != BatchStatus.COMPLETED) {
            throw new RuntimeException("Job failed: " + exec.getStatus());
        }
    }
}
