package com.example.datatransfer.factory;

import com.example.datatransfer.model.*;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.support.MapSqlParameterSource;
import org.springframework.batch.item.database.support.SqlParameterSourceProvider;
import org.springframework.batch.item.file.*;
import org.springframework.batch.item.file.transform.*;
import javax.sql.DataSource;
import java.util.stream.Collectors;

public class WriterFactory {
    public static ItemWriter<Map<String,Object>> get(DataEndpointSettings dst, List<SourceDestinationMapping> maps) throws Exception {
        return switch (dst.getType()) {
            case DATABASE -> dbWriter(dst.getDatabaseSettings(), maps);
            case FILE     -> fileWriter(dst.getFileSettings(), maps);
            case SCRIPT   -> new ScriptItemWriter(dst.getScriptSettings(), maps);
        };
    }
    private static JdbcBatchItemWriter<Map<String,Object>> dbWriter(DatabaseSettings db, List<SourceDestinationMapping> maps) {
        var w = new JdbcBatchItemWriter<Map<String,Object>>();
        w.setDataSource(ConnectionPoolFactory.getConnectionPool(db.getDatabaseId()));
        w.setSql(insertSql(db, maps));
        w.setItemSqlParameterSourceProvider(item -> {
            var src = new MapSqlParameterSource();
            item.forEach(src::addValue);
            return src;
        });
        w.afterPropertiesSet();
        return w;
    }
    private static String insertSql(DatabaseSettings db, List<SourceDestinationMapping> maps) {
        String cols = maps.stream()
            .map(SourceDestinationMapping::getDestinationColumnName)
            .collect(Collectors.joining(", "));
        String vals = maps.stream()
            .map(m -> ":" + m.getDestinationColumnName())
            .collect(Collectors.joining(", "));
        return "INSERT INTO " + db.getSchemaName() + "." + db.getTableName() +
               " (" + cols + ") VALUES (" + vals + ")";
    }
    private static FlatFileItemWriter<Map<String,Object>> fileWriter(FileSettings fs, List<SourceDestinationMapping> maps) throws Exception {
        if ("csv".equalsIgnoreCase(fs.getFileType())) {
            var w = new FlatFileItemWriter<Map<String,Object>>();
            w.setResource(new FileSystemResource(fs.getFilePath()));
            var agg = new DelimitedLineAggregator<Map<String,Object>>();
            agg.setDelimiter(fs.getFileDelimiter());
            agg.setFieldExtractor(item -> maps.stream()
                .map(m -> item.get(m.getDestinationColumnName())).toArray());
            w.setLineAggregator(agg);
            w.afterPropertiesSet();
            return w;
        }
        throw new IllegalArgumentException("Unsupported file type: " + fs.getFileType());
    }
}
