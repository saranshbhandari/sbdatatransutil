package com.example.datatransfer.model;

public class DataEndpointSettings {
    private DataEndpointType type;
    private DatabaseSettings databaseSettings;
    private FileSettings fileSettings;
    private ScriptSettings scriptSettings;
    // getters & setters
}
