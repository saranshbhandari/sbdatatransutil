package com.example.datatransfer.factory;

import com.example.datatransfer.model.ScriptSettings;
import com.example.datatransfer.model.SourceDestinationMapping;
import org.springframework.batch.item.ItemWriter;
import java.util.List;
import java.util.Map;

public class ScriptItemWriter implements ItemWriter<Map<String,Object>> {
    public ScriptItemWriter(ScriptSettings settings, List<SourceDestinationMapping> mappings) {
        // stub: implement your own scripting logic
    }

    @Override
    public void write(List<? extends Map<String,Object>> items) throws Exception {
        throw new UnsupportedOperationException("Script writing not implemented");
    }
}
