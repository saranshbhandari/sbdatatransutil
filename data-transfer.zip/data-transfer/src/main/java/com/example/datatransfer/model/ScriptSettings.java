package com.example.datatransfer.model;

public class ScriptSettings {
    private Long databaseId;
    private String script;
    // getters & setters
}
