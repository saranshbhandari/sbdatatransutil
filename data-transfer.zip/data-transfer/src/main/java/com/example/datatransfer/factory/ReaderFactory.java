package com.example.datatransfer.factory;

import com.example.datatransfer.model.*;
import com.example.datatransfer.processor.MapFieldSetMapper;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.file.*;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.core.io.FileSystemResource;
import java.util.*;
import org.springframework.beans.factory.InitializingBean;

public class ReaderFactory {
    public static ItemReader<Map<String,Object>> get(DataEndpointSettings src, List<SourceDestinationMapping> maps) throws Exception {
        return switch (src.getType()) {
            case DATABASE -> dbReader(src.getDatabaseSettings(), maps);
            case FILE     -> fileReader(src.getFileSettings(), maps);
            case SCRIPT   -> new ScriptItemReader(src.getScriptSettings(), maps);
        };
    }
    private static JdbcCursorItemReader<Map<String,Object>> dbReader(DatabaseSettings db, List<SourceDestinationMapping> maps) {
        var reader = new JdbcCursorItemReader<Map<String,Object>>();
        reader.setDataSource(ConnectionPoolFactory.getConnectionPool(db.getDatabaseId()));
        reader.setSql(selectSql(db, maps));
        reader.setRowMapper((rs, i) -> {
            var m = new HashMap<String,Object>();
            for (var col : maps) {
                m.put(col.getSourceColumnName(), rs.getObject(col.getSourceColumnName()));
            }
            return m;
        });
        return reader;
    }
    private static String selectSql(DatabaseSettings db, List<SourceDestinationMapping> maps) {
        String cols = String.join(", ", maps.stream()
            .map(SourceDestinationMapping::getSourceColumnName).toList());
        return "SELECT " + cols +
               " FROM " + db.getSchemaName() + "." + db.getTableName();
    }
    private static FlatFileItemReader<Map<String,Object>> fileReader(FileSettings fs, List<SourceDestinationMapping> maps) throws Exception {
        if ("csv".equalsIgnoreCase(fs.getFileType())) {
            var reader = new FlatFileItemReader<Map<String,Object>>();
            reader.setResource(new FileSystemResource(fs.getFilePath()));
            var tokenizer = new DelimitedLineTokenizer();
            tokenizer.setDelimiter(fs.getFileDelimiter());
            if (fs.isFirstRowIsHeader()) {
                tokenizer.setNames(maps.stream()
                    .map(SourceDestinationMapping::getSourceColumnName).toArray(String[]::new));
            } else {
                tokenizer.setNames(Arrays.stream(new String[maps.size()])
                    .map(i->"col"+Arrays.asList(maps).indexOf(i))
                    .toArray(String[]::new));
                tokenizer.setStrict(false);
            }
            var lineMapper = new DefaultLineMapper<Map<String,Object>>();
            lineMapper.setLineTokenizer(tokenizer);
            lineMapper.setFieldSetMapper(new MapFieldSetMapper(maps, fs.isFirstRowIsHeader()));
            reader.setLineMapper(lineMapper);
            return reader;
        }
        throw new IllegalArgumentException("Unsupported file type: " + fs.getFileType());
    }
}
