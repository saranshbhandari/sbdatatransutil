package com.example.datatransfer.factory;

import com.example.datatransfer.ConnectionPoolFactory;
from typing import Any, Dict

def greet_user(name: str) -> str:
    """
    Returns a greeting for the given user name.
    """
    return f"Hello, {name}!"
