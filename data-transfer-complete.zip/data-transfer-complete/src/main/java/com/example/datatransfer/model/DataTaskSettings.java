package com.example.datatransfer.model;

import java.util.List;

public class DataTaskSettings {
    private List<SourceDestinationMapping> mappings;
    private DataEndpointSettings source;
    private DataEndpointSettings destination;
    private int batchSize = 1000;
    private boolean rollbackOnFailure = true;
    // getters & setters
}
