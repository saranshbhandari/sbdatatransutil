package com.example.datatransfer.model;

public enum DataEndpointType {
    DATABASE, FILE, SCRIPT
}
