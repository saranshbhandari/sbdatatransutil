package com.example.datatransfer.model;

public class SourceDestinationMapping {
    private String sourceColumnName;
    private String sourceColumnType;
    private boolean sourceNullable;
    private String destinationColumnName;
    private String destinationColumnType;
    private boolean destinationNullable;
    // getters & setters
}
