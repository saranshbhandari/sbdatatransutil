package com.example.datatransfer.model;

public class FileSettings {
    private String filePath;
    private String fileType;
    private String fileDelimiter;
    private boolean firstRowIsHeader;
    // getters & setters
}
