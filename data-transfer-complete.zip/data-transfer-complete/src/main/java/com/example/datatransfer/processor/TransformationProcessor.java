package com.example.datatransfer.processor;

import com.example.datatransfer.model.SourceDestinationMapping;
import org.springframework.batch.item.ItemProcessor;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;

public class TransformationProcessor implements ItemProcessor<Map<String,Object>,Map<String,Object>> {
    private final List<SourceDestinationMapping> mappings;
    private final SimpleDateFormat dateFmt = new SimpleDateFormat("yyyy-MM-dd");
    public TransformationProcessor(List<SourceDestinationMapping> mappings) {
        this.mappings = mappings;
    }
    @Override
    public Map<String,Object> process(Map<String,Object> item) throws Exception {
        Map<String,Object> out = new HashMap<>();
        for (var m : mappings) {
            Object raw = item.get(m.getSourceColumnName());
            Object converted = convert(raw, m.getDestinationColumnType());
            out.put(m.getDestinationColumnName(), converted);
        }
        return out;
    }
    private Object convert(Object val, String targetType) {
        if (val == null) return null;
        var s = val.toString();
        try {
            return switch (targetType.toLowerCase()) {
                case "string"     -> s;
                case "integer"    -> Integer.valueOf(s);
                case "long"       -> Long.valueOf(s);
                case "double"     -> Double.valueOf(s);
                case "bigdecimal" -> new BigDecimal(s);
                case "boolean"    -> Boolean.valueOf(s);
                case "date"       -> dateFmt.parse(s);
                default           -> val;
            };
        } catch (Exception e) {
            throw new IllegalArgumentException("Failed to convert [" + s + "] to " + targetType, e);
        }
    }
}
