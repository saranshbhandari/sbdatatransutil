package com.example.datatransfer.factory;

import com.example.datatransfer.model.ScriptSettings;
import com.example.datatransfer.model.SourceDestinationMapping;
import org.springframework.batch.item.*;
import org.springframework.batch.item.database.builder.JdbcCursorItemReaderBuilder;
import org.springframework.beans.factory.InitializingBean;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

public class ScriptItemReader implements ItemReader<Map<String,Object>>, ItemStream, InitializingBean {
    private final ScriptSettings settings;
    private final List<SourceDestinationMapping> mappings;
    private JdbcCursorItemReader<Map<String,Object>> delegate;

    public ScriptItemReader(ScriptSettings settings, List<SourceDestinationMapping> mappings) {
        this.settings = settings;
        this.mappings = mappings;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        DataSource ds = ConnectionPoolFactory.getConnectionPool(settings.getDatabaseId());
        delegate = new JdbcCursorItemReaderBuilder<Map<String,Object>>()
            .name("scriptReader")
            .dataSource(ds)
            .sql(settings.getScript())
            .rowMapper((rs, rn) -> {
                Map<String,Object> row = new HashMap<>();
                for (var m : mappings) {
                    row.put(m.getSourceColumnName(), rs.getObject(m.getSourceColumnName()));
                }
                return row;
            })
            .build();
        delegate.afterPropertiesSet();
    }

    @Override public Map<String,Object> read() throws Exception { return delegate.read(); }
    @Override public void open(ExecutionContext ec) throws ItemStreamException { delegate.open(ec); }
    @Override public void update(ExecutionContext ec) throws ItemStreamException { delegate.update(ec); }
    @Override public void close() throws ItemStreamException { delegate.close(); }
}