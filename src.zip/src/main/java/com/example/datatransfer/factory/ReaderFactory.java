package com.example.datatransfer.factory;

import com.example.datatransfer.ConnectionPoolFactory;
import com.example.datatransfer.model.*;
import com.example.datatransfer.processor.MapFieldSetMapper;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.core.io.FileSystemResource;

import java.util.List;

public class ReaderFactory {
    public static ItemReader<Map<String,Object>> get(DataEndpointSettings src, List<SourceDestinationMapping> maps) throws Exception {
        switch (src.getType()) {
            case DATABASE:
                DatabaseSettings db = src.getDatabaseSettings();
                JdbcCursorItemReader<Map<String,Object>> reader = new JdbcCursorItemReader<>();
                reader.setDataSource(ConnectionPoolFactory.getConnectionPool(db.getDatabaseId()));
                reader.setSql(selectSql(db, maps));
                reader.setRowMapper((rs, rowNum) -> {
                    var m = new java.util.HashMap<String,Object>();
                    for (var col : maps) {
                        m.put(col.getSourceColumnName(), rs.getObject(col.getSourceColumnName()));
                    }
                    return m;
                });
                return reader;
            case FILE:
                FileSettings fs = src.getFileSettings();
                if ("csv".equalsIgnoreCase(fs.getFileType())) {
                    FlatFileItemReader<Map<String,Object>> csvReader = new FlatFileItemReader<>();
                    csvReader.setResource(new FileSystemResource(fs.getFilePath()));
                    DelimitedLineTokenizer tokenizer = new DelimitedLineTokenizer();
                    tokenizer.setDelimiter(fs.getFileDelimiter());
                    if (fs.isFirstRowIsHeader()) {
                        tokenizer.setNames(maps.stream()
                            .map(SourceDestinationMapping::getSourceColumnName)
                            .toArray(String[]::new));
                    } else {
                        tokenizer.setNames(java.util.stream.IntStream.range(0, maps.size())
                            .mapToObj(i -> "col" + i).toArray(String[]::new));
                        tokenizer.setStrict(false);
                    }
                    DefaultLineMapper<Map<String,Object>> lineMapper = new DefaultLineMapper<>();
                    lineMapper.setLineTokenizer(tokenizer);
                    lineMapper.setFieldSetMapper(new MapFieldSetMapper(maps, fs.isFirstRowIsHeader()));
                    csvReader.setLineMapper(lineMapper);
                    return csvReader;
                } else if ("excel".equalsIgnoreCase(fs.getFileType())) {
                    return new ExcelItemReader(fs, maps);
                } else {
                    throw new IllegalArgumentException("Unsupported file type: " + fs.getFileType());
                }
            case SCRIPT:
                return new ScriptItemReader(src.getScriptSettings(), maps);
            default:
                throw new IllegalArgumentException("Unknown source type");
        }
    }

    private static String selectSql(DatabaseSettings db, List<SourceDestinationMapping> maps) {
        String cols = String.join(", ", maps.stream()
            .map(SourceDestinationMapping::getSourceColumnName)
            .toList());
        return "SELECT " + cols + " FROM " + db.getSchemaName() + "." + db.getTableName();
    }
}