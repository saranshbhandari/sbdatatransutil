package com.example.datatransfer.factory;

import com.example.datatransfer.model.FileSettings;
import com.example.datatransfer.model.SourceDestinationMapping;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.eventusermodel.*;
import org.apache.poi.xssf.model.SharedStringsTable;
import org.apache.poi.xssf.usermodel.XSSFComment;
import org.springframework.batch.item.*;
import org.springframework.beans.factory.InitializingBean;
import org.xml.sax.InputSource;
import org.xml.sax.helpers.XMLReaderFactory;

import java.io.File;
import java.util.*;
import java.util.concurrent.LinkedBlockingQueue;

public class ExcelItemReader implements ItemReader<Map<String,Object>>, ItemStream, InitializingBean {
    private final String filePath;
    private final List<SourceDestinationMapping> mappings;
    private final boolean header;
    private final LinkedBlockingQueue<Map<String,Object>> queue = new LinkedBlockingQueue<>();
    private static final Map<String,Object> POISON = Collections.emptyMap();

    public ExcelItemReader(FileSettings fs, List<SourceDestinationMapping> mappings) {
        this.filePath = fs.getFilePath();
        this.mappings = mappings;
        this.header = fs.isFirstRowIsHeader();
    }

    @Override public void afterPropertiesSet() { new Thread(this::parse).start(); }

    private void parse() {
        try (OPCPackage pkg = OPCPackage.open(new File(filePath))) {
            XSSFReader reader = new XSSFReader(pkg);
            SharedStringsTable sst = reader.getSharedStringsTable();
            DataFormatter fmt = new DataFormatter();

            try (var sheet = reader.getSheetsData().next()) {
                var parser = XMLReaderFactory.createXMLReader();
                parser.setContentHandler(new XSSFSheetXMLHandler(
                    reader.getStylesTable(), sst, new Handler(), fmt, false));
                parser.parse(new InputSource(sheet));
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            queue.offer(POISON);
        }
    }

    @Override public Map<String,Object> read() throws Exception {
        var row = queue.take();
        return row == POISON ? null : row;
    }
    @Override public void open(ExecutionContext ec) {}
    @Override public void update(ExecutionContext ec) {}
    @Override public void close() {}

    private class Handler implements XSSFSheetXMLHandler.SheetContentsHandler {
        List<String> row = new ArrayList<>();
        int[] idx;
        @Override public void startRow(int rowNum) { row.clear(); }
        @Override public void endRow(int rowNum) {
            if (header && rowNum == 0) {
                idx = new int[mappings.size()];
                for (int i = 0; i < mappings.size(); i++)
                    idx[i] = row.indexOf(mappings.get(i).getSourceColumnName());
                return;
            }
            Map<String,Object> map = new HashMap<>();
            for (int i = 0; i < mappings.size(); i++) {
                int j = idx[i];
                String val = (j >= 0 && j < row.size()) ? row.get(j) : null;
                map.put(mappings.get(i).getSourceColumnName(), val);
            }
            queue.offer(map);
        }
        @Override public void cell(String cellRef, String val, XSSFComment cm) { row.add(val); }
        @Override public void headerFooter(String text, boolean isHdr, String tag) {}
    }
}