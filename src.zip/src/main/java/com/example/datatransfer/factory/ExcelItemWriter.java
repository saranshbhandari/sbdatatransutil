package com.example.datatransfer.factory;

import com.example.datatransfer.model.FileSettings;
import com.example.datatransfer.model.SourceDestinationMapping;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.batch.item.*;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.*;

public class ExcelItemWriter implements ItemWriter<Map<String,Object>>, ItemStream, InitializingBean {
    private final List<SourceDestinationMapping> mappings;
    private final boolean header;
    private SXSSFWorkbook wb;
    private Sheet sheet;
    private int rowNum;
    private static final String FMT = "yyyyMMddHHmmss";

    public ExcelItemWriter(FileSettings fs, List<SourceDestinationMapping> mappings) {
        this.mappings = mappings;
        this.header = fs.isFirstRowIsHeader();
    }

    @Override public void afterPropertiesSet() {}
    @Override public void open(ExecutionContext ec) {
        wb = new SXSSFWorkbook();
        sheet = wb.createSheet("Sheet1");
        rowNum = 0;
        if (header) {
            Row r = sheet.createRow(rowNum++);
            for (int i = 0; i < mappings.size(); i++)
                r.createCell(i).setCellValue(mappings.get(i).getDestinationColumnName());
        }
    }

    @Override public void write(List<? extends Map<String,Object>> items) throws Exception {
        for (var item : items) {
            Row r = sheet.createRow(rowNum++);
            for (int i = 0; i < mappings.size(); i++) {
                Object v = item.get(mappings.get(i).getDestinationColumnName());
                Cell c = r.createCell(i);
                if (v instanceof Number) c.setCellValue(((Number)v).doubleValue());
                else if (v instanceof Boolean) c.setCellValue((Boolean)v);
                else if (v instanceof Date) c.setCellValue((Date)v);
                else if (v != null) c.setCellValue(v.toString());
            }
        }
    }

    @Override public void close() {
        try {
            String fn = "data-" + new SimpleDateFormat(FMT).format(new Date()) + ".xlsx";
            try (FileOutputStream out = new FileOutputStream(fn)) { wb.write(out); }
            wb.dispose(); wb.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    @Override public void update(ExecutionContext ec) {}
}