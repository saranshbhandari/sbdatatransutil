package com.example.datatransfer.factory;

import com.example.datatransfer.ConnectionPoolFactory;
import com.example.datatransfer.model.*;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.support.MapSqlParameterSource;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.transform.DelimitedLineAggregator;
import org.springframework.core.io.FileSystemResource;

import java.util.stream.Collectors;

public class WriterFactory {
    public static ItemWriter<Map<String,Object>> get(DataEndpointSettings dst, List<SourceDestinationMapping> maps) throws Exception {
        switch (dst.getType()) {
            case DATABASE:
                DatabaseSettings db = dst.getDatabaseSettings();
                JdbcBatchItemWriter<Map<String,Object>> writer = new JdbcBatchItemWriter<>();
                writer.setDataSource(ConnectionPoolFactory.getConnectionPool(db.getDatabaseId()));
                writer.setSql(insertSql(db, maps));
                writer.setItemSqlParameterSourceProvider(item -> {
                    var params = new MapSqlParameterSource();
                    item.forEach(params::addValue);
                    return params;
                });
                writer.afterPropertiesSet();
                return writer;
            case FILE:
                FileSettings fs = dst.getFileSettings();
                if ("csv".equalsIgnoreCase(fs.getFileType())) {
                    FlatFileItemWriter<Map<String,Object>> csvWriter = new FlatFileItemWriter<>();
                    csvWriter.setResource(new FileSystemResource(fs.getFilePath()));
                    DelimitedLineAggregator<Map<String,Object>> agg = new DelimitedLineAggregator<>();
                    agg.setDelimiter(fs.getFileDelimiter());
                    agg.setFieldExtractor(item -> maps.stream()
                        .map(m -> item.get(m.getDestinationColumnName()))
                        .toArray());
                    csvWriter.setLineAggregator(agg);
                    csvWriter.afterPropertiesSet();
                    return csvWriter;
                } else if ("excel".equalsIgnoreCase(fs.getFileType())) {
                    return new ExcelItemWriter(fs, maps);
                } else {
                    throw new IllegalArgumentException("Unsupported file type: " + fs.getFileType());
                }
            case SCRIPT:
                return new ScriptItemWriter(dst.getScriptSettings(), maps);
            default:
                throw new IllegalArgumentException("Unknown destination type");
        }
    }

    private static String insertSql(DatabaseSettings db, List<SourceDestinationMapping> maps) {
        String cols = maps.stream()
            .map(SourceDestinationMapping::getDestinationColumnName)
            .collect(Collectors.joining(", "));
        String vals = maps.stream()
            .map(m -> ":" + m.getDestinationColumnName())
            .collect(Collectors.joining(", "));
        return "INSERT INTO " + db.getSchemaName() + "." + db.getTableName() +
               " (" + cols + ") VALUES (" + vals + ")";
    }
}